#include <stdio.h>

void pow2(int x)
{
    int y;
    y = x*x;
}

int main ()
{
    pow2(7);
    printf("calculated pow2 of 7");
    return 0;
}
